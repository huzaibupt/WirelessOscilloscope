/* Scan Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

/*
    This example shows how to use the All Channel Scan or Fast Scan to connect
    to a Wi-Fi network.

    In the Fast Scan mode, the scan will stop as soon as the first network matching
    the SSID is found. In this mode, an application can set threshold for the
    authentication mode and the Signal strength. Networks that do not meet the
    threshold requirements will be ignored.

    In the All Channel Scan mode, the scan will end only after all the channels
    are scanned, and connection will start with the best network. The networks
    can be sorted based on Authentication Mode or Signal Strength. The priority
    for the Authentication mode is:  WPA2 > WPA > WEP > Open
*/
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_event_loop.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "tcpip_adapter.h"
#include "lwip/api.h"
#include "lwip/err.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include <lwip/netdb.h>
#include "esp_err.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include <math.h>
#include <sys/param.h>
//#include "protocol_examples_common.h"
//wifi soft-ap
#define EXAMPLE_ESP_WIFI_SSID      "esp32"
#define EXAMPLE_ESP_WIFI_PASS      "12344321"
#define EXAMPLE_MAX_STA_CONN       5
//TCP Server
#define PORT      				   10000
/* pin of SPI*/
#define PIN_NUM_MISO 17
#define PIN_NUM_MOSI 16
#define PIN_NUM_CLK  18
#define PIN_NUM_CS   5

#define PIN_NUM_DC   19

#define PARALLEL_LINES 16
//TCP Server
#define TCP_SERVER_PORT 10000

static const char *TAG = "ESP32";
char tcp_server_sendbuf[200]="Data:#76543210#CH1:#20#,CH2:#50#\r\n";
/*char tcp_server_sendbuf_high[200];
char tcp_server_sendbuf_low[200];*/
uint32_t rx_data = 0x41615a7a;
uint32_t flag_high1_low0 = 0;
//SPI
spi_device_handle_t spi; 	//SPI device handle
gpio_config_t io_conf;		//gpio configuration

void spi_dataformat_conversion(uint32_t rx_data)//date format conversion
{
	//***����ת������4****���Ʋ���3*****ESP32�����3һ�£�Qt������ʮ�������ݴ���������****
	tcp_server_sendbuf[6]  =  (((rx_data & 0x80) == 0)?0x30:0x31);
	tcp_server_sendbuf[7]  =  (((rx_data & 0x40) == 0)?0x30:0x31);
	tcp_server_sendbuf[8]  =  (((rx_data & 0x20) == 0)?0x30:0x31);
	tcp_server_sendbuf[9]  =  (((rx_data & 0x10) == 0)?0x30:0x31);
	tcp_server_sendbuf[10] =  (((rx_data & 0x08) == 0)?0x30:0x31);
	tcp_server_sendbuf[11] =  (((rx_data & 0x04) == 0)?0x30:0x31);
	tcp_server_sendbuf[12] =  (((rx_data & 0x02) == 0)?0x30:0x31);
	tcp_server_sendbuf[13] =  (((rx_data & 0x01) == 0)?0x30:0x31);
	/*if((tcp_server_sendbuf[6] == 0x31)||(tcp_server_sendbuf[7] == 0x31)||(tcp_server_sendbuf[8] == 0x31))//��λ
		strcpy(tcp_server_sendbuf_high,tcp_server_sendbuf);
	else if((tcp_server_sendbuf[6] == 0x31)&&(tcp_server_sendbuf[7] == 0x31)&&(tcp_server_sendbuf[8] == 0x31))//��λ
		strcpy(tcp_server_sendbuf_low,tcp_server_sendbuf);*/

	printf("Cur_date:#%x#%d#\n",rx_data,rx_data);
	/*for(int i = 6;i<=13;i++)
		if(tcp_client_sendbuf[i] == 0x30) printf("0");
		else if(tcp_client_sendbuf[i] == 0x31) printf("1");
	printf("\n");*/
}

void spi_tran_cmd(spi_device_handle_t spi, const uint8_t cmd)//Send a command to the FPGA.
{
    esp_err_t ret;
    spi_transaction_t t;
    memset(&t, 0, sizeof(t));       //Zero out the transaction
    t.length=8;                     //Command is 8 bits
    t.tx_buffer=&cmd;               //The data is the cmd itself
    t.user=(void*)0;                //D/C needs to be set to 0
    ret=spi_device_polling_transmit(spi, &t);  //Transmit!
    assert(ret==ESP_OK);            //Should have had no issues.
}

uint32_t spi_get_adc_data(spi_device_handle_t spi)//spi get adc date
{
	if(flag_high1_low0 == 0)//��FPGA���͵�λ
	{
		spi_tran_cmd(spi,0x33);
		flag_high1_low0 = 1;
	}
	else if(flag_high1_low0 == 1)//��FPGA���͸�λ
	{
		spi_tran_cmd(spi,0x44);
		flag_high1_low0 = 0;
	}
    spi_transaction_t t;
    memset(&t, 0, sizeof(t));
    t.length=8;
    t.flags = SPI_TRANS_USE_RXDATA;
    t.user = (void*)1;

    esp_err_t ret = spi_device_polling_transmit(spi, &t);
    assert( ret == ESP_OK );

    return *(uint32_t*)t.rx_data;
}

void TCP_Server(void *pvParameter)
{
	uint32_t data_len = 0;
	struct pbuf *q;
	esp_err_t err,recv_err;
	//u8_t remot_addr[4];		//�����洢�ͻ���IP�Ͷ˿ں�
	struct netconn *server_conn, *newconn;
	static ip_addr_t ipaddr;
	static u16_t port;
    char tcp_server_recvbuf[200];
    LWIP_UNUSED_ARG(pvParameter);
    while(1)
    {	/*����TCP���󶨡�����*/
    	server_conn = netconn_new(NETCONN_TCP);//create TCP connect
    	netconn_bind(server_conn,IP_ADDR_ANY,TCP_SERVER_PORT);
    	netconn_listen(server_conn);

    	/* ��ֹ�����̣߳��ȴ�ʱ��Ϊ 10ms */
    	server_conn->recv_timeout = 10;

    	while (1)
    	{
    		err = netconn_accept(server_conn,&newconn);
    		if(err==ERR_OK) newconn->recv_timeout = 10;
    		if (err == ERR_OK)
    		{
    			struct netbuf *recvbuf;

    	        /* ��ȡ���ͻ��˵� IP ���˿ں� */
    			/*netconn_getaddr(newconn,&ipaddr,&port,0);

    			remot_addr[3] = (u8_t)(ipaddr.u_addr >> 24);
    			remot_addr[2] = (u8_t)(ipaddr.u_addr >> 16);
    			remot_addr[1] = (u8_t)(ipaddr.u_addr >> 8);
    			remot_addr[0] = (u8_t)(ipaddr.u_addr);
    			printf("������%d.%d.%d.%d �����Ϸ������������˿ں�Ϊ��%d\r\n",remot_addr[0], remot_addr[1],remot_addr[2],remot_addr[3],port);
				*/
    			while(1)
    			{

    				/**************************receive date through spi******************/
    				//rx_data = 0x0f;
    			    rx_data = spi_get_adc_data(spi);
    				spi_dataformat_conversion(rx_data);
    				//printf("spi...\r\n");
    				/*****************************Sending Date********************************/
    				/* ��ͻ��˷�����Ϣ */
    				/*if(flag_high1_low0 == 0)
    				{
    					err = netconn_write(newconn,tcp_server_sendbuf_high,strlen((char*)tcp_server_sendbuf_high),NETCONN_COPY);
    					flag_high1_low0 = 1;
    				}
    				else if(flag_high1_low0 == 1)
					{
		    			err = netconn_write(newconn,tcp_server_sendbuf_low,strlen((char*)tcp_server_sendbuf_low),NETCONN_COPY);
		    			flag_high1_low0 = 0;
		    		}*/
    				err = netconn_write(newconn,tcp_server_sendbuf,strlen((char*)tcp_server_sendbuf),NETCONN_COPY);
    				if(err != ERR_OK)
    				{
    					printf("����ʧ��\r\n");
    				}

    				/******************************Receiving Date***************************** */
    				if((recv_err = netconn_recv(newconn,&recvbuf)) == ERR_OK)
    				{
    					memset(tcp_server_recvbuf,0,200);//���200�ֽ�

    					/* ����������Ϣת�浽�Զ���ռ� */
    					for(q=recvbuf->p;q!=NULL;q=q->next)
    					{
    						if(q->len > (200-data_len))
    	                    memcpy(tcp_server_recvbuf+data_len,q->payload,(200-data_len));
    						else memcpy(tcp_server_recvbuf+data_len,q->payload,q->len);
    						data_len += q->len;
    						if(data_len > 200) break;
    					}
    					data_len=0;
    					printf("%s\r\n",tcp_server_recvbuf);

    					if(strcmp(tcp_server_recvbuf,"123")==0)
    						spi_tran_cmd(spi, 0x11);//���ǲ�
    					else if(strcmp(tcp_server_recvbuf,"321")==0)
    						spi_tran_cmd(spi, 0x22);//���Ҳ�
    					vTaskDelay(1000/portTICK_PERIOD_MS);
    					netbuf_delete(recvbuf);

    				/* �Ͽ����� */
    				}else if(recv_err == ERR_CLSD)
    				{
    					netconn_close(newconn);
    					netconn_delete(newconn);
    					//printf("������%d.%d.%d.%d �Ͽ��������������\r\n",remot_addr[0], remot_addr[1],remot_addr[2],remot_addr[3]);
    					break;
    				}
    				//spi_tran_cmd(spi,0x00);
    				//vTaskDelay(1000/portTICK_PERIOD_MS);
    			}
    		}
    	}
    }
}



static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                                    int32_t event_id, void* event_data)
{
    if (event_id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t* event = (wifi_event_ap_staconnected_t*) event_data;
        ESP_LOGI(TAG, "station "MACSTR" join, AID=%d",
                 MAC2STR(event->mac), event->aid);
        xTaskCreate(TCP_Server, "server", 2048, NULL, (tskIDLE_PRIORITY + 2), NULL);

    } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t* event = (wifi_event_ap_stadisconnected_t*) event_data;
        ESP_LOGI(TAG, "station "MACSTR" leave, AID=%d",
                 MAC2STR(event->mac), event->aid);
    }
}

/* Initialize Wi-Fi as ap */
void wifi_init_softap()
{
    tcpip_adapter_init();
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = EXAMPLE_ESP_WIFI_SSID,
            .ssid_len = strlen(EXAMPLE_ESP_WIFI_SSID),
            .password = EXAMPLE_ESP_WIFI_PASS,
            .max_connection = EXAMPLE_MAX_STA_CONN,
            .authmode = WIFI_AUTH_WPA_WPA2_PSK
        },
    };
    if (strlen(EXAMPLE_ESP_WIFI_PASS) == 0) {
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
    }

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "wifi_init_softap finished. SSID:%s password:%s",
             EXAMPLE_ESP_WIFI_SSID, EXAMPLE_ESP_WIFI_PASS);
}

//This function is called (in irq context!) just before a transmission starts. It will
//set the D/C line to the value indicated in the user field.
void spi_pre_transfer_callback(spi_transaction_t *t)//command or data
{
    int dc=(int)t->user;
    gpio_set_level(PIN_NUM_DC, dc);
}

//spi_device_handle_t
void gpio_spi_init()//gpio & spi init
{
	//************gpio init
	gpio_set_direction(PIN_NUM_DC, GPIO_MODE_OUTPUT);

	//************spi init
	esp_err_t ret;
	//spi_device_handle_t spi;
	spi_bus_config_t buscfg={
	   .miso_io_num=PIN_NUM_MISO,
	   .mosi_io_num=PIN_NUM_MOSI,
	   .sclk_io_num=PIN_NUM_CLK,
	   .quadwp_io_num=-1,
	   .quadhd_io_num=-1,
	   .max_transfer_sz=PARALLEL_LINES*320*2+8
	};
	spi_device_interface_config_t devcfg={
	   .clock_speed_hz=1*1000*1000,           //Clock out at 1 MHz
	   .mode=0,                                //SPI mode 0
	   .spics_io_num=PIN_NUM_CS,               //CS pin
	   .queue_size=7,                          //We want to be able to queue 7 transactions at a time
	   .pre_cb=spi_pre_transfer_callback,  //Specify pre-transfer callback to handle D/C line
	};
	//*************Initialize the SPI bus
	ret=spi_bus_initialize(HSPI_HOST, &buscfg, 1);
	ESP_ERROR_CHECK(ret);

	//*************Attach the device to the SPI bus
	ret=spi_bus_add_device(HSPI_HOST, &devcfg, &spi);
	ESP_ERROR_CHECK(ret);
    //return spi;
}

void app_main()
{
    // Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK( ret );

    gpio_spi_init();
    spi_tran_cmd(spi, 0x00);
    /*while(1)
    {
    	spi_tran_cmd(spi, 0x11);
    	printf("111111\r\n");
    	vTaskDelay(2000/portTICK_PERIOD_MS);

    	spi_tran_cmd(spi, 0x22);
    	printf("222222\r\n");
    	vTaskDelay(2000/portTICK_PERIOD_MS);

    	spi_tran_cmd(spi, 0x33);
    	printf("333333\r\n");
    	vTaskDelay(2000/portTICK_PERIOD_MS);

    	spi_tran_cmd(spi, 0x44);
    	printf("444444\r\n");
    	vTaskDelay(2000/portTICK_PERIOD_MS);

    	spi_tran_cmd(spi, 0x88);
    	printf("555555\r\n");
    	vTaskDelay(2000/portTICK_PERIOD_MS);
    }*/
    ESP_LOGI(TAG, "ESP_WIFI_MODE_AP");
    wifi_init_softap();
}


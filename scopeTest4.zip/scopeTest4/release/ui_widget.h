/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout_2;
    QSlider *SliderYCenter;
    QCustomPlot *widget1;
    QWidget *widget2;
    QGridLayout *gridLayout;
    QTextEdit *textEditTest;
    QPushButton *closeButton;
    QTextEdit *textEditR;
    QPushButton *clearButton;
    QToolButton *waveControltoolButton;
    QPushButton *connectButton;
    QSlider *SliderYZoom;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1159, 678);
        gridLayout_2 = new QGridLayout(Widget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        SliderYCenter = new QSlider(Widget);
        SliderYCenter->setObjectName(QString::fromUtf8("SliderYCenter"));
        SliderYCenter->setOrientation(Qt::Horizontal);

        gridLayout_2->addWidget(SliderYCenter, 0, 1, 1, 1);

        widget1 = new QCustomPlot(Widget);
        widget1->setObjectName(QString::fromUtf8("widget1"));

        gridLayout_2->addWidget(widget1, 1, 1, 1, 1);

        widget2 = new QWidget(Widget);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setStyleSheet(QString::fromUtf8("font: 18pt \"\346\226\260\345\256\213\344\275\223\";"));
        gridLayout = new QGridLayout(widget2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        textEditTest = new QTextEdit(widget2);
        textEditTest->setObjectName(QString::fromUtf8("textEditTest"));

        gridLayout->addWidget(textEditTest, 2, 1, 1, 2);

        closeButton = new QPushButton(widget2);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));

        gridLayout->addWidget(closeButton, 0, 1, 1, 1);

        textEditR = new QTextEdit(widget2);
        textEditR->setObjectName(QString::fromUtf8("textEditR"));

        gridLayout->addWidget(textEditR, 1, 1, 1, 2);

        clearButton = new QPushButton(widget2);
        clearButton->setObjectName(QString::fromUtf8("clearButton"));

        gridLayout->addWidget(clearButton, 0, 2, 1, 1);

        waveControltoolButton = new QToolButton(widget2);
        waveControltoolButton->setObjectName(QString::fromUtf8("waveControltoolButton"));
        waveControltoolButton->setPopupMode(QToolButton::MenuButtonPopup);
        waveControltoolButton->setToolButtonStyle(Qt::ToolButtonTextOnly);
        waveControltoolButton->setAutoRaise(true);
        waveControltoolButton->setArrowType(Qt::DownArrow);

        gridLayout->addWidget(waveControltoolButton, 3, 1, 1, 1);

        connectButton = new QPushButton(widget2);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));

        gridLayout->addWidget(connectButton, 3, 2, 1, 1);


        gridLayout_2->addWidget(widget2, 0, 0, 3, 1);

        SliderYZoom = new QSlider(Widget);
        SliderYZoom->setObjectName(QString::fromUtf8("SliderYZoom"));
        SliderYZoom->setOrientation(Qt::Horizontal);

        gridLayout_2->addWidget(SliderYZoom, 2, 1, 1, 1);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        closeButton->setText(QCoreApplication::translate("Widget", "Close", nullptr));
        clearButton->setText(QCoreApplication::translate("Widget", "Clear", nullptr));
        waveControltoolButton->setText(QCoreApplication::translate("Widget", "DswControl", nullptr));
        connectButton->setText(QCoreApplication::translate("Widget", "Connect", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H

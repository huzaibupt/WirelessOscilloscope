#include "widget.h"
#include "ui_widget.h"
#include <math.h>
#include <QHostAddress>
#include "QDebug"
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    Timer = new QTimer(this);
    InitChart();//图表初始化
    setWindowTitle("示波器");
    //******UI设计预处理
    QMenu *pMenu = new QMenu(this);
    pMenu->addAction(QString("三角波"));
    pMenu->addAction(QString("正弦波"));
    ui->waveControltoolButton->setMenu(pMenu);

    //******串口需要
    //InitPort();
    //QTimer::singleShot(10,this,&Scope::ReadPort);//每10ms执行一次

    //******客户端需要
    /*tcpSocket = NULL;

    //分配空间，指定父对象
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket,&QTcpSocket::connected,[=](){

        ui->textEditR->setText("成功和服务器建立好连接");

    });

    connect(tcpSocket,&QTcpSocket::readyRead,[=](){
        //获取对方发送的内容
        array = tcpSocket->readAll();

        //追加到编辑区中
        ui->textEditR->append(array);

    });*/

    //获取服务器的ip和端口
    /*QString ip = "192.168.4.1";
    qint16 port = 10000;

    //主动和服务器建立连接
    tcpSocket->connectToHost(QHostAddress(ip),port);*/

    QTimer::singleShot(1,this,&Widget::ReadPort);
    Clk = 0;
}

Widget::~Widget()
{
    delete ui;
}

void Widget::InitChart()
{
    //设置滑动块调节Y轴范围和默认值
    ui->SliderYCenter->setRange(-10,10);
    ui->SliderYCenter->setValue(0);
    ui->SliderYZoom->setRange(-10,10);
    ui->SliderYZoom->setValue(0);
    //数据位设置
    XData.resize(5000);//XData.resize(50);
    XData.value(0,1);
    YData.resize(5000);//YData.resize(50);
    //Y1Data.resize(50);
    //Y2Data.resize(50);

    //画图相关
    Plot = ui->widget1;
    Plot->addGraph();
    //Plot->addGraph();
    //Plot->addGraph();

    Plot->graph(0)->setPen(QPen(Qt::red));
    //Plot->graph(1)->setPen(QPen(Qt::blue));
    //Plot->graph(2)->setPen(QPen(Qt::green));

    Plot->xAxis->setLabel("S");
    Plot->yAxis->setLabel("mV");
    Plot->yAxis->setRange(-2,6);
    Plot->xAxis->rescale(true);

    GraphShow();
}

/* 来自下位机的数据格式
 * "Data:(0)#%d(1)#CH1:(2)#%d(3)#,CH2:(4)#%d(5)#\r\n(6)"
 * 括号内的内容为和#有关的第几个字符,数据位为1\3\5，1为测试数据位，3\5分别为通道1\2的数据位
 */
void Widget::GetData(QString str)
{
    if(str.isEmpty())
        return;
    /*if(str.section("#",0,0) != "Data:")
        return;*/
    /***数据转换****/
    //double num = str.section("#",1,1).toDouble();//测试数据位

    //double num1 = str.section("#",3,3).toDouble();//通道1
    //double num2 = str.section("#",5,5).toDouble();//通道2
    /*if(num <= 0 || num1 <= 0)   //对无效数据滤除或进行阈值选择
        return ;*/

    /***数据转换测试1**直接使用1个字节的十六进制数据**/
    /*int rx_data = str.section("#",1,1).toInt();
    int rx_data2 = rx_data & 0x1f;  //高三位清零
    //测试窗口
    ui->textEditTest->setText(QString("测试"));
    //ui->textEditTest->append(QString(rx_data2));
    if((rx_data & 0x80) == 0x00)    //低位
        lowData = rx_data2/1024;
    else if((rx_data & 0x80) == 0x80)   //高位
        highData = rx_data2/32;
    double num = 3.3*(lowData+highData);*/

    /***数据转换测试2**ESP32已经将1个字节的十六进制数据处理为8个字节的十六进制数据（每个字节代表原来的1bit）**/
    /*QString rx_data = str.section("#",1,1);
    if(rx_data[0])
        ;
    还未完成*/

    /***数据转换测试3**ESP32已经将1个字节的十六进制数据处理为十进制数据*****/
    /*int rx_data = str.section("#",1,1).toInt();
    if(rx_data < 32)    //低位
        lowData = rx_data/1024;
    else if(rx_data >= 32)   //高位
        highData = (rx_data-32)/32;
    double num = 3.3*(lowData+highData);*/

    /***数据转换测试4****类似测试3*****ESP32与测试3一致，Qt程序中十进制数据代表二进制****/
    int rx_data = str.section("#",1,1).toInt();
    decimalData = ((rx_data/10000)%10)*16+((rx_data/1000)%10)*8+((rx_data/100)%10)*4+((rx_data/10)%10)*2+(rx_data%10);
    if(rx_data < 100000)    //低位
        lowData = decimalData/1024;
    else if(rx_data >= 100000)   //高位
        highData = decimalData/32;

    qDebug("高位：%lf",highData);
    qDebug("低位：%lf",lowData);
    double num = 3.3*(lowData+highData);
    /****数据入栈*****/
    XData.pop_front();
    XData.push_back(Clk++);

    YData.pop_front();
    YData.push_back(num);

    //qDebug("Data:%f#%lf#%f#%f#%d",num,decimalData,lowData,highData,rx_data);

    //Y1Data.pop_front();
    //Y1Data.push_back(num1);
    //Y2Data.pop_front();
    //Y2Data.push_back(num2);
}

void Widget::GraphShow()
{
    Plot->graph(0)->setData(XData,YData);
    //Plot->graph(1)->setData(XData,Y1Data);
    //Plot->graph(2)->setData(XData,Y2Data);
    Plot->yAxis->setRange(SliderYMin,SliderYMax);
    Plot->xAxis->rescale(true);
    Plot->replot();
}

void Widget::ReadPort()
{
    QTimer::singleShot(1,this,&Widget::ReadPort);
    /*QString str = "111";
    //发送数据，使用套接字是tcpSocket
    tcpSocket->write(str.toUtf8().data());*/

    /*if(SerialPort.isOpen() == false)
        return;
    QByteArray temp = SerialPort.readAll();
    if(temp.isEmpty())
        return;
    ui->textEdit->append(QString(temp));*/
    if(array.isEmpty())
        return;
    GetData(QString(array));
    GraphShow();
};

void Widget::on_SliderYCenter_sliderMoved(int position)//纵轴中心位置调节
{
    SliderYError = position;
    SliderYMin = SliderYMin+SliderYError;
    SliderYMax = SliderYMax+SliderYError;
}

void Widget::on_SliderYZoom_sliderMoved(int position)//纵轴缩放
{
    SliderYError = position;
    SliderYMin = SliderYMin-SliderYError;
    SliderYMax = SliderYMax+SliderYError;
}

void Widget::on_clearButton_clicked()//清除接收区内容
{
    ui->textEditR->clear();
    /*XData.clear();
    YData.clear();*/
    Clk = 0;
}

void Widget::on_closeButton_clicked()//断开与客服端的连接
{
    if(NULL == tcpSocket)
    {
        return ;
    }
    /*XData.clear();
    YData.clear();*/
    /*decimalData = 0;
    lowData = 0;
    highData = 0;*/
    //主动和客户端端口断开连接
    tcpSocket->disconnectFromHost();
    tcpSocket->close();

    tcpSocket = NULL;
}


void Widget::on_waveControltoolButton_triggered(QAction *arg1)
{
    QString str;
    QString MenuItemSelect = arg1->text();
    if(MenuItemSelect == QString("三角波"))
    {
        qDebug("三角波");
        str = "123";
    }
    else if(MenuItemSelect == QString("正弦波"))
    {
        qDebug("正弦波");
        str = "321";
    }
    //发送数据，使用套接字是tcpSocket
    tcpSocket->write(str.toUtf8().data());
}

void Widget::on_connectButton_clicked()
{
    //******客户端需要
    tcpSocket = NULL;

    //分配空间，指定父对象
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket,&QTcpSocket::connected,[=](){

        ui->textEditR->setText("成功和服务器建立好连接");

    });

    connect(tcpSocket,&QTcpSocket::readyRead,[=](){
        //获取对方发送的内容
        array = tcpSocket->readAll();

        //追加到编辑区中
        ui->textEditR->append(array);

    });
    //获取服务器的ip和端口
    QString ip = "192.168.4.1";
    qint16 port = 10000;
    //主动和服务器建立连接
    tcpSocket->connectToHost(QHostAddress(ip),port);
}

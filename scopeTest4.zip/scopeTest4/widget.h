#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
/*****串口需要的头文件
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>*/
#include <QTimer>
#include "qcustomplot.h"
#include <QVector>
//*****服务器需要两个套接字,客户端只需要一个套接字
#include <QTcpSocket>//通信套接字
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    //void InitPort();
    void InitChart();
    void ReadPort();
    void GraphShow();
    void GetData(QString);
private slots:
    void on_SliderYCenter_sliderMoved(int position);

    void on_SliderYZoom_sliderMoved(int position);

    void on_clearButton_clicked();

    void on_closeButton_clicked();

    void on_waveControltoolButton_triggered(QAction *arg1);

    void on_connectButton_clicked();

private:
    Ui::Widget *ui;
    QTimer *Timer;
    //QSerialPort SerialPort;
    //QSerialPortInfo SerialPortInfo;
    int Clk ;

    QCustomPlot *Plot;
    QVector <double>    XData;
    QVector <double>    YData;
    //QVector <double>    Y1Data;
    //QVector <double>    Y2Data;

    qint32 SliderYMax = 4;
    qint32 SliderYMin = -1;
    qint32 SliderYError;

    //*****客户端需要的数据成员
    //使用指针或者变量都是可以的，不过使用指针的话，需要动态的分配空间
    QTcpSocket  *tcpSocket;//通信套接字
    QByteArray array;//数据
    double highData = 0;
    double lowData = 0;
    double decimalData = 0;
};

#endif // WIDGET_H










